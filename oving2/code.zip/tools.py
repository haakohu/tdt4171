import math as m
def normalize(vec):
  return vec / sum(vec)